
<script>
$(function() {
    $('a[href="https://www.1stdibs.com/dealers/pat-mcgann/"]').attr('target', '_blank');
})
</script>